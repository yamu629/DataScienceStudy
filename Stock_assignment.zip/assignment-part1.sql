-- Create schema
 create schema assignment;

-- Use schema
 use assignment;
 
### Import tables through wizard, keep date as text
-- Verify count after import 
select count(*)  as count_bajaj from bajaj ;
select count(*) as count_eicher from eicher ;
select count(*) as count_hero from hero ;
select count(*) as count_infosys from infosys ;
select count(*) as count_tcs from tcs;
select count(*) as count_tvs from tvs;

-- Safe update mode disabling to avoid error code 1175
 SET SQL_SAFE_UPDATES = 0;
 
 -- All imported tables have date column as text. 
 -- Hence changing date column to date format and altering the column to date datatype
 update bajaj set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table bajaj modify date DATE;
update eicher set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table eicher modify date DATE;
update hero set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table hero modify date DATE;
update infosys set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table infosys modify date DATE;
update tcs set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table tcs modify date DATE;
update tvs set date = STR_TO_DATE(date,'%d-%M-%Y') ;
alter table tvs modify date DATE;



### Creating table with 20 days moving average and 50 days moving average excluding first 49 rows
create table bajaj1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from bajaj order by date desc limit 839);
 
 create table eicher1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from eicher order by date desc limit 839);
 
 create table hero1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from hero order by date desc limit 839);
 
 create table infosys1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from infosys order by date desc limit 839);
 
 create table tcs1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from tcs order by date desc limit 839);
 
 create table tvs1 as (
    SELECT   date, 
 round(avg(`Close Price`) over (order by date asc rows between 19 preceding and current row),2) as `20 Day MA`,
 round(avg(`Close Price`) over (order by date asc rows between 49 preceding and current row),2) as `50 Day MA`
 from tvs order by date desc limit 839);
 
 
### TO CREATE MASTER TABLE 
-- Create temp table to store all possible values of date from all tables
 create table temp_Date(Date DATE);

-- Populate temp table
insert into temp_Date (Date)
select bajaj.date from bajaj left join tcs  on tcs.date=bajaj.date
UNION 
select tcs.date from tcs left join bajaj on tcs.date=bajaj.date order by date;

--- Create master table
create table close_master (Date DATE , Bajaj float,TCS float, TVS float,Infosys float,Eicher float,Hero float);

-- Populate data
 insert into close_master(date,Bajaj,TCS,TVS,Infosys,Eicher,Hero) 
 select t.date,b.`Close Price`,tc.`Close Price`,tv.`Close Price`,i.`Close Price`,e.`Close Price`,h.`Close Price` 
 from temp_Date t left join bajaj b using(date) left join tcs tc using (date)
 left join tvs tv using (date)
 left  join infosys i using (date)
left  join eicher e using (date)
left join hero h using (date); 

-- Verifying table data
select * from close_master;

-- Kindly note that for 2015-12-09, ClosePrice is null for TCS,TVS,Eicher,Hero
-- For 2017-08-31, ClosePrice is null for Bajaj and Infosys

### TO GENERATE SIGNALS
-- Create lag views
create view bajaj_lag_vw as
select Date, c.bajaj as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from bajaj1 join close_master c using (date)
window w as (order by Date);

create view hero_lag_vw as
select Date, c.hero as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from hero1 join close_master c using (date)
window w as (order by Date);

create view infosys_lag_vw as
select Date, c.infosys as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from infosys1 join close_master c using (date)
window w as (order by Date);

create view tvs_lag_vw as
select Date, c.tvs as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from tvs1 join close_master c using (date)
window w as (order by Date);

create view tcs_lag_vw as
select Date, c.tcs as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from tcs1 join close_master c using (date)
window w as (order by Date);

create view eicher_lag_vw as
select Date, c.eicher as `Close Price`, `20 Day MA`, lag(`20 Day MA`,1) over w as 20_MA_prev, `50 Day MA`, lag(`50 Day MA`,1) over w as 50_MA_prev
from eicher1 join close_master c using (date)
window w as (order by Date);

-- Checking view
select * from bajaj_lag_vw;

-- Creating signal tables
create table bajaj2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from bajaj_lag_vw;


create table hero2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from hero_lag_vw;


create table eicher2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from eicher_lag_vw;


create table infosys2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from infosys_lag_vw;


create table tcs2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from tcs_lag_vw;


create table tvs2
select Date,`Close Price`,
(case when `20 Day MA` > `50 Day MA` and 20_MA_prev < 50_MA_prev then 'BUY'
when `20 Day MA` < `50 Day MA` and 20_MA_prev > 50_MA_prev then 'SELL'
else 'HOLD' end) as 'Signal'
from tvs_lag_vw;

-- Verifying one table
select * from bajaj2;

### Creating User defined function
-- Returns Signal if input date between min(date) and max(date) and Signal is not null
-- Returns 'HOLD' if input date between min(date) and max(date) and Signal is null
-- Returns 'DATE OUTSIDE RANGE' if input date >max(date) and input date<min(date)

delimiter $$
create function get_signal_bajaj (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from bajaj2 where Date = s);
set date_min=(select min(Date) from bajaj2);
set date_max=(select max(Date) from bajaj2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;


delimiter $$
create function get_signal_eicher (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from eicher2 where Date = s);
set date_min=(select min(Date) from eicher2);
set date_max=(select max(Date) from eicher2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;


delimiter $$
create function get_signal_hero (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from hero2 where Date = s);
set date_min=(select min(Date) from hero2);
set date_max=(select max(Date) from hero2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;


delimiter $$
create function get_signal_infosys (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from infosys2 where Date = s);
set date_min=(select min(Date) from infosys2);
set date_max=(select max(Date) from infosys2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;


delimiter $$
create function get_signal_tcs (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from tcs2 where Date = s);
set date_min=(select min(Date) from tcs2);
set date_max=(select max(Date) from tcs2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;


delimiter $$
create function get_signal_tvs (s date)
returns char(50) deterministic
begin
declare s_value varchar(20);
declare date_min date;
declare date_max date;
set s_value = (select  `Signal`
                        from tvs2 where Date = s);
set date_min=(select min(Date) from tvs2);
set date_max=(select max(Date) from tvs2);
                        
if s<date_min then
	set s_value='DATE OUTSIDE RANGE';
elseif s>date_max then
	set s_value='DATE OUTSIDE RANGE';
elseif s_value is NULL then
	set s_value='HOLD';
	
end if;
return s_value;
end
$$
delimiter ;

-- Verifying various conditions for functions
-- Input Date <min(Date)
select get_signal_tvs('2014-10-11') as `signal`;
-- Input Date  > max(Date)
select get_signal_tvs('2020-10-11') as `signal`;
-- Input Date as value between min and max dates but not present in table
select get_signal_tvs('2015-10-11') as `signal`;
-- Input Date which does not return null
select get_signal_tvs('2015-06-26') as `signal`;










